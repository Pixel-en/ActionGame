Thanks alot for downloading my '16x16 Animated Top-down Character' asset pack! I hope you will enjoy it!

I will happily shout out anything you make using one of my packs! You can send me a message on Itch or
Twitter! 

https://twitter.com/RunninBlood

LICENCE:
After buying the pack you are free to use the assets in both free and commercial projects.
You can also edit these assets to your own liking.
Giving me credit is not needed but much appreciated!

You may NOT reupload or re-sell these assets in any way!